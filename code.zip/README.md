# Customer Deletion Audit Agent

A production-grade, Python standard-library audit agent built to independently audit and verify customer data deletion requests (GDPR / "Right to be Forgotten") across distributed databases, system logs, multi-service exports, shift handovers, PDF documents, and UI console screenshots.

---

## 1. System Architecture

The agent implements an end-to-end 6-stage auditing pipeline that adheres to the **Golden Rule of Auditing**: *claimed success from deletion workers is treated as a claim, not proof; only factual evidence snapshots decide the true state at audit time.*

```
Customer Request (email, request_text, audit_at)
       |
       +---> [1. Identity Resolver] (src/identity.py)
       |        Resolves current email, historical emails, phones, and hashes
       |        across user_identities.csv and user_audit_log.csv
       |
       +---> [2. Intent Classifier] (src/intent.py)
       |        Discriminates deletion requests from routine inquiries in 4 languages
       |        (Flags non-deletion requests as NOT_APPLICABLE)
       |
       +---> [3. Evidence Harvester & Replay] (src/evidence.py, src/state.py, src/multimodal.py)
       |        - Gathers SQL snapshots (sqlite3), service JSON exports, and logs (regex)
       |        - Tier-1 Multimodal: pure stdlib PDF stream decoding + native Vision OCR
       |        - Reconstructs chronological timeline up to audit_at timestamp
       |
       +---> [4. Policy & Rule Engine] (src/rules.py)
       |        Enforces deletion_rules.csv, detecting REMAINING_RECORD, EXPOSED_PII,
       |        ACTIVE_DATA_FLOW, and RESTORE_RISK while allowing valid tombstones
       |
       +---> [5. Audit Planner & Sorter] (src/planner.py)
       |        Plans REMEDIATION and VERIFICATION steps, strictly sorted by:
       |        Phase -> Operation Order -> system_id -> resource_id
       |
       +---> [6. Output & Benchmark Evaluation] (output.csv, evaluate.py)
                Generates 518-case output.csv and benchmarks accuracy
```

---

## 2. Directory Structure

```text
.
├── dataset/                                # Hackathon dataset and raw evidence
│   ├── deletion_requests.csv               # 518 customer deletion requests
│   ├── sample_deletion_requests.csv        # 32 sample requests for benchmarking
│   ├── sample_output.csv                   # Ground truth answers for sample cases
│   ├── deletion_rules.csv                  # Policy treatment rules
│   ├── evidence_files.csv                  # Evidence manifest (96 files)
│   ├── system_activity.csv                 # 4,500 worker logs and claimed activities
│   ├── user_identities.csv                 # Current customer identity records
│   ├── user_audit_log.csv                  # Historical audit logs of identity changes
│   └── evidence/                           # SQL, JSON, log, PDF, and PNG files
├── bin/
│   └── ocr                                 # Local native Apple Vision OCR binary
├── cache/                                  # Cached plain text & metadata per evidence file
├── src/                                    # Core agent source modules
│   ├── identity.py                         # Stage 2: Multi-hop identity resolver
│   ├── intent.py                           # Stage 3: Multilingual intent classifier
│   ├── evidence.py                         # Stage 4: Subsystem & manifest evidence harvester
│   ├── state.py                            # Stage 4: Timeline replay & resource state builder
│   ├── rules.py                            # Stage 5: Policy rule interpreter & finding evaluator
│   ├── planner.py                          # Stage 6: Step planner, sorter & output.csv generator
│   ├── multimodal.py                       # Stage 8: PDF stream decompressor & OCR pipeline
│   ├── inspect_data.py                     # Stage 1: Dataset schema inspector
│   └── inspector.py                        # Stage 1: Initial schema discovery utility
├── evaluation/
│   ├── evaluation_report.md                # Final benchmark & extra test cases report
│   ├── usage_report.md                     # LLM token, model, and cost accounting report
│   ├── failures_log.md                     # Running failure log with root causes & fixes
│   ├── usage_log.csv                       # Detailed token log per model call
│   └── extra_cases/                        # 3 extra test cases designed by team
│       ├── extra_deletion_requests.csv     # Extra input requests
│       ├── extra_expected_output.csv       # Expected output standards
│       └── cases_description.md            # Detailed rationale for extra cases
├── evaluate.py                             # Evaluation harness for benchmarks and extra cases
├── output.csv                              # Full 518-case generated audit output
└── README.md                               # Complete system documentation
```

---

## 3. How to Run Everything from Scratch

### Prerequisites
- **Python 3.10+** (using only the Python standard library; no `pip install` required).
- **macOS (Apple Silicon / Intel)** for the local native OCR binary in `bin/ocr`.

### Primary Execution
To run the full end-to-end deletion audit pipeline across all 518 cases and generate `output.csv`:
```bash
python3 main.py
```

### Dataset Schema Inspection (Optional)
To inspect schemas, file counts, and sample records across all dataset files:
```bash
python3 main.py --inspect
```

### Modular Stage Verifications & Benchmarking
Individual stages can also be executed independently for inspection, testing, and evaluation:

- **Stage 2: Identity Resolution**
  ```bash
  python3 src/identity.py
  ```

- **Stage 3: Intent Classification**
  ```bash
  python3 src/intent.py
  ```

- **Stage 4: Timeline Replay & Resource State Reconstruction**
  ```bash
  python3 src/state.py
  ```

- **Stage 5: Policy Rules & Findings Engine**
  ```bash
  python3 src/rules.py
  ```

- **Stage 6: Planner & Step Sorting Demo**
  ```bash
  python3 src/planner.py
  ```

- **Stage 8: Multimodal Evidence Extraction (PDF / OCR)**
  ```bash
  python3 src/multimodal.py
  ```

- **Benchmark Accuracy Evaluation (32 Sample Cases)**
  ```bash
  python3 evaluate.py
  ```

- **Extra Test Cases Evaluation (Historical Aliases, Non-Deletion, False Claims)**
  ```bash
  python3 evaluate.py --extra
  ```

---

## 4. Key Engineering Highlights

1. **Zero External Dependencies:** Built strictly on Python's built-in standard library (`csv`, `json`, `sqlite3`, `re`, `base64`, `zlib`, `pathlib`).
2. **Zero Cloud API Costs:** The two-tier multimodal pipeline parses 100% of PDFs via Adobe stream decoding (`base64.a85decode` + `zlib.decompress`) and 100% of PNG images via Apple Vision framework (`bin/ocr`), resulting in **$0.00 spent on LLM tokens**.
3. **Auditor Skepticism:** Replays events in strict chronological order and ignores post-`audit_at` events, ensuring that worker "success" claims are never accepted without evidence.
4. **Deterministic Step Sorting:** All remediation and verification steps are sorted by `(phase_rank, op_rank, system_id, resource_id)` as required by the problem specification.
