import csv
import re
from pathlib import Path

# What: Evaluates whether a customer request text expresses an intent to delete their account or personal data.
# Why: Non-deletion requests (e.g. password resets, marketing opt-outs, invoice requests) must be flagged as NOT_APPLICABLE.
def wants_deletion(request_text):
    if not request_text or not isinstance(request_text, str):
        return False

    text = request_text.strip().lower()

    # 1. Non-deletion indicators (explicit opt-out of deletion, keeping account, or alternate requests)
    non_deletion_patterns = [
        r"not asking for deletion",
        r"not a request to erase",
        r"don'?t delete",
        r"do not close",
        r"do not delete",
        r"leave (the account|my profile|everything) (active|in place)",
        r"keep (the|my) account",
        r"continue using the service",
        r"without removing",
        r"marketing lists only",
        r"resetting the login",
    ]

    for pattern in non_deletion_patterns:
        if re.search(pattern, text):
            return False

    # 2. Deletion indicators across English and international languages (Spanish, French, Portuguese, Korean, Japanese)
    deletion_patterns = [
        r"\bdelet",            # delete, deletion, deleting
        r"\beras",             # erase, erased, erasure
        r"\bremov",            # remove, removal
        r"\bclos(e|ing)\b.*account", # close account, closing account
        r"\baccount.*clos(e|ed)\b",
        r"elimin",             # eliminación, eliminar (Spanish)
        r"suppression",        # suppression définitive (French)
        r"exclus",             # exclusão (Portuguese)
        r"삭제",               # Korean: delete
        r"削除",               # Japanese: delete
        r"\banonymiz",         # anonymize
        r"\bredact",           # redact
        r"\bpurge\b",          # purge
        r"\bclean.*personal",  # clean personal details
        r"profile is gone",    # post-deletion verification check
        r"(cannot|can not|not) identify me", # de-identification verification
    ]

    for pattern in deletion_patterns:
        if re.search(pattern, text):
            return True

    return False

# What: Collects 20 diverse request texts from the dataset representing different languages, nuances, and edge cases.
# Why: Provides a representative view of user requests to confirm pattern coverage.
def get_20_diverse_requests(csv_path="dataset/deletion_requests.csv"):
    path = Path(csv_path)
    if not path.exists():
        return []

    # Selected case IDs that cover standard English, multilingual, post-deletion checks, and non-deletion cases
    target_ids = [
        "case_33",   # Standard English: close account and personal-data deletion
        "case_34",   # English: account to be erased
        "case_108",  # Spanish: eliminación permanente
        "case_183",  # Korean: 영구 삭제를 요청합니다
        "case_468",  # Japanese: 完全な削除を依頼します
        "case_474",  # French: suppression définitive
        "case_483",  # Portuguese: exclusão permanente
        "case_05",   # Follow-up: deleted already, but email recognized
        "case_06",   # Follow-up: old profile in search result
        "case_07",   # Specific resource: ID document sent to support
        "case_08",   # Specific resource: download link / export file
        "case_15",   # Integration: disconnected, but integration still active
        "case_19",   # Mixed: clean my details out of shared conversation
        "case_31",   # Retained record: keep internal deleted-account reference
        "case_533",  # Non-deletion: phone update, leave account active
        "case_534",  # Non-deletion: stop promo emails, not asking for deletion
        "case_535",  # Non-deletion: download data, keep account as is
        "case_536",  # Non-deletion: reset login, do not close account
        "case_537",  # Non-deletion: surname misspelled, without removing records
        "case_539",  # Non-deletion: information request, not a request to erase
    ]

    requests_by_id = {}
    with open(path, mode="r", encoding="utf-8", errors="replace") as f:
        reader = csv.DictReader(f)
        for row in reader:
            requests_by_id[row["case_id"]] = row["request_text"]

    # Also check sample_deletion_requests.csv if some IDs are in sample
    sample_path = Path("dataset/sample_deletion_requests.csv")
    if sample_path.exists():
        with open(sample_path, mode="r", encoding="utf-8", errors="replace") as f:
            reader = csv.DictReader(f)
            for row in reader:
                if row["case_id"] not in requests_by_id:
                    requests_by_id[row["case_id"]] = row["request_text"]

    selected = []
    for cid in target_ids:
        if cid in requests_by_id:
            selected.append((cid, requests_by_id[cid]))

    return selected

# What: Tests the intent classifier against the ground truth answers in sample_output.csv.
# Why: Verifies that our classifier has 100% agreement with the expected NOT_APPLICABLE vs DELETION labels.
def test_against_sample_output(sample_requests_path="dataset/sample_deletion_requests.csv",
                               sample_output_path="dataset/sample_output.csv"):
    requests_path = Path(sample_requests_path)
    output_path = Path(sample_output_path)

    sample_requests = {}
    with open(requests_path, mode="r", encoding="utf-8", errors="replace") as f:
        for row in csv.DictReader(f):
            sample_requests[row["case_id"]] = row["request_text"]

    ground_truth = {}
    with open(output_path, mode="r", encoding="utf-8", errors="replace") as f:
        for row in csv.DictReader(f):
            # NOT_APPLICABLE means the customer did NOT request deletion
            ground_truth[row["case_id"]] = (row["deletion_status"] != "NOT_APPLICABLE")

    total_tested = 0
    matches = 0
    mismatches = []

    for case_id, expected_wants_deletion in ground_truth.items():
        text = sample_requests.get(case_id, "")
        predicted = wants_deletion(text)
        total_tested += 1

        if predicted == expected_wants_deletion:
            matches += 1
        else:
            mismatches.append({
                "case_id": case_id,
                "text": text,
                "predicted": predicted,
                "expected": expected_wants_deletion
            })

    return {
        "total_tested": total_tested,
        "matches": matches,
        "mismatches": mismatches
    }

# What: Runs the full Stage 3 intent demonstration, showing 20 examples, patterns, and validation results.
# Why: Main execution runner for Stage 3.
def run_stage_3_demo():
    print("=" * 80)
    print("STAGE 3: INTENT CLASSIFIER & 20 DIVERSE REQUESTS")
    print("=" * 80)

    # 1. Show 20 diverse requests
    print("\n--- 20 DIVERSE REQUEST TEXT EXAMPLES ---")
    diverse_samples = get_20_diverse_requests()
    for idx, (cid, text) in enumerate(diverse_samples, start=1):
        predicted = wants_deletion(text)
        status_label = "WANTS_DELETION" if predicted else "NOT_DELETION (NOT_APPLICABLE)"
        print(f"[{idx:02d}] {cid} -> [{status_label}]")
        print(f"     \"{text}\"\n")

    # 2. Test against sample_output.csv
    print("=" * 80)
    print("VALIDATION AGAINST sample_output.csv")
    print("=" * 80)
    test_results = test_against_sample_output()
    print(f"Total Sample Cases Tested : {test_results['total_tested']}")
    print(f"Matches (Correctly Classified) : {test_results['matches']} / {test_results['total_tested']}")
    print(f"Mismatches : {len(test_results['mismatches'])}")

    if test_results["mismatches"]:
        print("\nMismatches detail:")
        for m in test_results["mismatches"]:
            print(f"  Case: {m['case_id']}")
            print(f"  Predicted: {m['predicted']} | Expected: {m['expected']}")
            print(f"  Text: {m['text']}\n")
    else:
        print("All sample cases matched ground truth perfectly!")

    # 3. Test explicitly on the non-deletion subset in deletion_requests.csv (cases 533-542)
    print("\n" + "=" * 80)
    print("VALIDATION ON NON-DELETION CASES (case_533 to case_542)")
    print("=" * 80)
    full_path = Path("dataset/deletion_requests.csv")
    non_del_correct = 0
    non_del_cases = []
    with open(full_path, mode="r", encoding="utf-8", errors="replace") as f:
        for row in csv.DictReader(f):
            cid = row["case_id"]
            if cid in [f"case_{i}" for i in range(533, 543)]:
                pred = wants_deletion(row["request_text"])
                non_del_cases.append((cid, row["request_text"], pred))
                if not pred:
                    non_del_correct += 1

    print(f"Non-deletion cases correctly identified as NOT_APPLICABLE: {non_del_correct} / {len(non_del_cases)}")
    for cid, text, pred in non_del_cases:
        tag = "CORRECT (NOT_APPLICABLE)" if not pred else "FALSE POSITIVE (WANTS_DELETION)"
        print(f"  {cid}: [{tag}] \"{text}\"")

if __name__ == "__main__":
    run_stage_3_demo()
