# Evaluation Failures Log

A running log of audit agent failures identified during benchmark evaluation, documenting root causes, proposed remediations, user approvals, and before/after verification metrics.

---

## Failure #1: Unparsed Multi-Service Subsystem Evidence (`evidence_03`, `evidence_92`, `evidence_94`)

### Date Logged
2026-10-25

### Affected Cases
`case_11`, `case_13`, `case_18`, `case_29`, `case_30` (and related multi-service cases)

### Description & Root Cause
In Stage 7 evaluation, the top 5 worst cases were all caused by our evidence scanner missing secondary subsystem data (such as search indexes, customer support tickets, analytics profiles, and active connector data flows).
- In `evidence_03` (`customer_account_handover_20261001.txt`), the file uses a pipe-delimited format:
  `Timestamp | system_id | resource_id | data_category | status | identifier`
  Our generic log scanner did not parse these pipe-delimited columns into structured resource states.
- In `evidence_92` (`service_resource_export_20260915_114455.json`), data is organized by subsystem:
  `account_service`, `analytics_platform`, `search_service`, `support_platform`, `integration_service`, and `backup_service`.
  Our generic JSON scanner only searched for top-level dictionaries and missed nested search index hits, active connector flags, and unredacted support excerpts.
- In `evidence_94` (`resource_lookup_trace_20260926_103856.log`), readback verification lookups across multiple services were not parsed into multi-resource verification checks.

Because these files were not parsed into concrete resource states, the planner falsely assumed that only the primary account existed, prematurely classifying `INCOMPLETE` cases as `COMPLETE` with a single verification step instead of planning full remediation across all 4 affected services.

### Proposed Fix
1. **Dedicated Handover Parser (`src/evidence.py`)**:
   Parse pipe-delimited shift handover files (`evidence_03`) into structured resource records with exact `system_id`, `resource_id`, `data_category`, and `status` (`NOT_FOUND` → `ABSENT`, `FOUND` → `PRESENT`, `ACTIVE` → `ACTIVE`, `IDENTIFIABLE` → `PRESENT`).
2. **Dedicated Multi-Service Export Parser (`src/evidence.py`)**:
   Parse `service_resource_export_*.json` (`evidence_92`) across all 8 service blocks:
   - `search_service`: hit count > 0 → `PRESENT` (finding: `REPORT_REMAINING_RECORD`)
   - `support_platform`: requester email present → `PRESENT` (finding: `REPORT_EXPOSED_PII`)
   - `analytics_platform`: email/customer reference present → `PRESENT` (finding: `REPORT_EXPOSED_PII`)
   - `integration_service`: connector enabled == True → `ACTIVE` (finding: `REPORT_ACTIVE_DATA_FLOW`)
   - `backup_service`: restore_allowed == True → `ACTIVE` (finding: `REPORT_RESTORE_RISK`)
   - `security_service`: audit records retained → `PRESENT` (verification: `VERIFY_RECORD_PRESENT`)
3. **Multi-Service Timeline & State Replay (`src/state.py` & `src/planner.py`)**:
   Feed all discovered subsystem resources into the state replay timeline and plan verification for all affected services.

### Resolution & Verification
- **Status:** Resolved (Approved by User)
- **Changes Applied:**
  1. Implemented `parse_handover_report()`, `parse_service_resource_export()`, and `parse_resource_lookup_trace()` in `src/evidence.py` to convert pipe-delimited logs, service exports, and trace lookups into structured resource records.
  2. Enhanced `reconstruct_resource_states()` in `src/state.py` to carry forward subsystem resource identifiers, systems, states, and findings.
  3. Updated `plan_case()` in `src/planner.py` to plan complete multi-subsystem remediations and verify all affected secondary services (including legal retention audit records in `security_service`).
  4. Regenerated `output.csv` with 518 validated rows.

### Before vs After Evaluation Metrics

| Metric | Before Fix (Baseline) | After Fix (Resolved) | Improvement |
| :--- | :--- | :--- | :--- |
| **Status Accuracy** | **50.00%** (16/32 cases) | **75.00%** (24/32 cases) | **+25.00%** |
| **Sequence Accuracy (Exact)** | **9.38%** (3/32 cases) | **15.62%** (5/32 cases) | **+6.24%** |
| **Step-Level Match Accuracy** | **12.44%** (24/193 steps) | **52.85%** (102/193 steps) | **+40.41% (4.2x)** |
| **Field Accuracy: `phase`** | 64.81% | 93.42% | +28.61% |
| **Field Accuracy: `system_id`** | 53.70% | 62.50% | +8.80% |
| **Field Accuracy: `resource_id`** | 37.04% | 64.47% | +27.43% |
| **Field Accuracy: `operation`** | 59.26% | 78.95% | +19.69% |
| **Field Accuracy: `state`** | 55.56% | 78.29% | +22.73% |
| **Field Accuracy: `evidence_id`** | 90.74% | 97.37% | +6.63% |

---

## Failure #2: Substring Search Bleed, Raw Origin Folders & Evidence-First Account Resolution (Cases 1 & 3)

### Date Logged
2026-10-25

### Affected Cases
- **Extra Cases:** `case_extra_01` (Old email resolution for `user_12`), `case_extra_03` (Misleading status check for `user_61`).
- **Sample Cases:** `case_26` (Word boundary bleed in logs), `case_21` (Spurious legal register finding), `case_12` (Disputed order reference in steps), `case_09` (Log event timestamp correlation).

### Description & Root Cause in Simple Words
During extra cases evaluation, two main issues appeared:
1. **Case 1 (Old Email & Spurious Order Finding):**
   When `user_12` submitted a request using an old email, our scanner correctly resolved `user_12`. However, it scanned `evidence_27` (a multi-user tax and dispute register) and picked up the first order reference on the page (`ORD-20264118`, belonging to `user_08`). Because our rule engine didn't recognize order references as compliant legal holds under `rule_13`, it treated it as a missing deletion, adding 4 spurious steps.
2. **Case 3 (Misleading Status & Audit Cutoff Timestamp):**
   In `case_extra_03` (and sample `case_09`), the user had a restore risk (`backup_4978`) and a retained audit log (`audit_record_4902`). However, the log file (`evidence_06`) was packaged into an archive on `2026-09-18`, while the case audit cutoff was `2026-09-16T09:00:00Z`. Because our code used the archive file date instead of the actual event timestamp written on the log line (`2026-09-16T08:52:59Z`), the log line was discarded as being "in the future," missing `audit_record_4902`.
3. **Log Substring Matching:**
   In log files, searching for `user_26` without word boundaries matched `user_261` through `user_269`, pulling in unrelated records with escaped quotes (`\"support_9996\"`) and turning clean sample cases like `case_26` into false failures.

### Proposed Fix
1. **Dynamic Canonical System Mapping:**
   Map table names (e.g. `backup_restore_entries`), service loggers, and resource prefixes to the 9 canonical systems dynamically via `get_canonical_system_id()`, rather than relying on raw origin folder names like `customer_data_inventory_capture`.
2. **Evidence-First Account Resource Discovery:**
   Search evidence records, log lookup traces, and snapshot contents for explicit `account_` resource IDs (e.g. `account_3960`, `account_9797`) before falling back to default numbering.
3. **Exact Word Boundaries in Log Search:**
   Wrap search terms in `\b(?:\b...\b)` regex patterns and cleanly strip escaped quotes (`strip('\'"\\')`) so `user_26` only matches `user_26`.
4. **Log Line Event Timestamps:**
   Extract ISO event timestamps directly from log lines so events occurring before `audit_at` are properly recognized even if the log file was archived later.
5. **Rule 13 Legal Retention Compliance:**
   Recognize disputed orders and tax registers as legally retained under `rule_13` (`LEGAL_HOLD_RECORD -> RETAIN`), preventing them from generating false deletion findings.

### Resolution & Verification
- **Status:** Resolved (General Fix Applied)
- **Changes Applied:**
  1. Updated `search_log_file()` in `src/evidence.py` to enforce regex word boundaries, extract line timestamps, clean nested quotes, and correlate related lines by `trace_id`.
  2. Updated `search_sql_snapshot()` in `src/evidence.py` to derive canonical system ID, resource ID, state, and findings dynamically from SQL table schemas and record data.
  3. Updated `parse_multimodal_evidence()` in `src/evidence.py` and `evaluate_resource_finding()` in `src/rules.py` to handle legal hold records under `rule_13`.
  4. Updated `plan_case()` in `src/planner.py` to discover account resource IDs directly from evidence content and restrict security verification strictly to `audit_record_` identifiers.

### Before vs After Evaluation Metrics

#### 32 Sample Cases:
| Metric | Before Fix | After Fix | Improvement |
| :--- | :--- | :--- | :--- |
| **Status Accuracy** | **90.62%** (29/32 cases) | **93.75%** (30/32 cases) | **+3.13% (+1 case)** |
| **Sequence Accuracy (Exact)** | **18.75%** (6/32 cases) | **34.38%** (11/32 cases) | **+15.63% (nearly doubled!)** |
| **Step-Level Match Accuracy** | **73.58%** (142/193 steps) | **76.17%** (147/193 steps) | **+2.59% (+5 steps)** |
| **Field Accuracy: `phase`** | 84.30% | 95.18% | +10.88% |
| **Field Accuracy: `system_id`** | 63.95% | 81.93% | **+17.98%** |
| **Field Accuracy: `resource_id`** | 55.23% | 74.70% | **+19.47%** |
| **Field Accuracy: `operation`** | 62.21% | 80.72% | +18.51% |
| **Field Accuracy: `state`** | 66.28% | 81.33% | +15.05% |
| **Field Accuracy: `evidence_id`** | 88.37% | 98.80% | +10.43% |

#### 3 Extra Test Cases:
| Case ID | Scenario | Expected Status | Actual Status | Step Match | Sequence Match |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `case_extra_01` | Old Email Alias (`user_12`) | `INCOMPLETE` | `INCOMPLETE` | **100.00%** (5/5) | **100% PERFECT MATCH** |
| `case_extra_02` | Non-Deletion Intent (`user_01`) | `NOT_APPLICABLE` | `NOT_APPLICABLE` | **100.00%** (0/0 `[]`) | **100% PERFECT MATCH** |
| `case_extra_03` | Misleading Status (`user_61`) | `INCOMPLETE` | `INCOMPLETE` | **100.00%** (5/5) | **100% PERFECT MATCH** |


---

## Stage 8: Multimodal Evidence Resolution (PDF Documents & PNG Console Screenshots)

### Date Logged
2026-10-25

### Affected Cases
- **Sample Dataset (32 cases):** `case_07` (directly depends on `evidence_58`), plus cross-referenced cases (`case_08`, `case_12`, `case_17`, `case_21`, `case_24`, `case_29`).
- **Full Dataset (518 cases):** Exactly 11 unique cases depend on PDF/Image multimodal evidence:
  `case_33`, `case_34`, `case_35`, `case_39`, `case_45`, `case_46`, `case_50`, `case_52`, `case_53`, `case_55`, `case_61`.

### Description & Root Cause
In Stage 4, PDF documents (`.pdf`) and PNG UI screenshots (`.png`) were intentionally cataloged but skipped during timeline reconstruction. This caused cases with evidence residing exclusively in attachments or UI consoles (e.g. `case_07` depending on `evidence_58`: `delivery_correction_attachment.pdf`) to fall back to generic dummy objects or misclassified statuses.

### Proposed Two-Tier Pipeline
1. **Tier 1 (Plain Text & Local OCR):**
   - **PDF Text Extraction:** Python standard library (`base64.a85decode` + `zlib.decompress` + PDF stream operator parsing) to extract text content streams from Adobe PDFs.
   - **Image OCR:** Compiled local native OCR (`bin/ocr`) using Apple's Vision framework (`VNRecognizeTextRequest`) to extract structured text from UI screenshots.
2. **Tier 2 (LLM Fallback & Token Logging):**
   - Only invoke an LLM if Tier 1 text extraction or OCR yields empty or unreadable results (<10 characters).
   - Log `timestamp, file_id, file_name, model_name, input_tokens, output_tokens, cost_usd` to `evaluation/usage_log.csv`.
3. **Caching:**
   - Cache extracted results per file in `cache/<file_id>.txt` and metadata in `cache/<file_id>.json` to eliminate redundant extraction work.

### Resolution & Verification
- **Status:** Resolved
- **Changes Applied:**
  1. Created `src/multimodal.py` implementing stream decompression, OCR execution, per-file caching in `cache/`, LLM fallback logging in `evaluation/usage_log.csv`, and dataset dependency analysis.
  2. 100% of the 15 multimodal files (4 PDFs, 11 PNGs) were extracted successfully via Tier 1 without requiring external LLM API calls, maintaining total LLM token cost at **$0.00**.
  3. Integrated `parse_multimodal_evidence()` into `src/evidence.py` to route `.pdf` and `.png` files into structured evidence findings during evidence gathering.
  4. Refined fallback handling in `src/rules.py` to ensure resources without non-compliance evidence are marked compliant.
  5. Verified `case_07` reached a perfect **100% exact sequence match** against canonical ground truth.

### Before vs After Evaluation Metrics

| Metric | Before Stage 8 (Post-Failure #1) | After Stage 8 (Multimodal Integration) | Improvement |
| :--- | :--- | :--- | :--- |
| **Status Accuracy** | **75.00%** (24/32 cases) | **84.38%** (27/32 cases) | **+9.38% (+3 cases)** |
| **Sequence Accuracy (Exact)** | **15.62%** (5/32 cases) | **18.75%** (6/32 cases) | **+3.13% (+1 case)** |
| **Step-Level Match Accuracy** | **52.85%** (102/193 steps) | **54.40%** (105/193 steps) | **+1.55% (+3 steps)** |
| **LLM Token Cost** | $0.00 | $0.00 (100% local Tier 1 OCR/PDF extraction) | $0.00 spent |

