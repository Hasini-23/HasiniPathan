# main.py
# Main entry point for the Deletion Audit Agent project

import argparse
import sys
from pathlib import Path

# Ensure project root is on sys.path
PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.inspect_data import run_inspection
from src.planner import generate_output_csv, validate_output_file


def main():
    parser = argparse.ArgumentParser(
        description="Customer Deletion Audit Agent - Full End-to-End Pipeline"
    )
    parser.add_argument(
        "--inspect",
        action="store_true",
        help="Run dataset schema inspection instead of the full audit pipeline",
    )
    args = parser.parse_args()

    if args.inspect:
        run_inspection()
    else:
        print("=" * 80)
        print("CUSTOMER DELETION AUDIT AGENT - FULL PIPELINE EXECUTION")
        print("=" * 80)
        print("Running full deletion audit pipeline on dataset/deletion_requests.csv...")
        output_rows = generate_output_csv(
            input_csv="dataset/deletion_requests.csv",
            output_csv_path="output.csv",
        )
        print(f"Generated {len(output_rows)} rows in output.csv.")

        is_valid, message = validate_output_file("output.csv")
        print(f"Validation Status: {'PASS' if is_valid else 'FAIL'}")
        print(f"Validation Detail: {message}")

        status_counts = {}
        for r in output_rows:
            status_counts[r["deletion_status"]] = status_counts.get(r["deletion_status"], 0) + 1
        print(f"\nStatus Distribution across {len(output_rows)} cases: {status_counts}")
        print("=" * 80)


if __name__ == "__main__":
    main()
