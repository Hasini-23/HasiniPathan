import csv
import json
import sys
from pathlib import Path

# Ensure project root is in sys.path
ROOT_DIR = Path(__file__).resolve().parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from src.identity import resolve_identity
from src.evidence import gather_all_evidence_for_user
from src.state import (
    load_system_activity_for_user,
    build_chronological_timeline,
    reconstruct_resource_states,
)
from src.planner import plan_case

# What: Runs the full audit pipeline on all sample requests to produce actual predictions.
# Why: Generates our model's predictions dynamically so we can compare against the benchmark key.
def run_sample_predictions(sample_requests_path="dataset/sample_deletion_requests.csv"):
    path = Path(sample_requests_path)
    predictions = {}

    with open(path, mode="r", encoding="utf-8", errors="replace") as f:
        cases = list(csv.DictReader(f))

    for c in cases:
        cid = c["case_id"]
        email = c["email"]
        audit_at = c["audit_at"]

        id_res = resolve_identity(email)
        user_bundle = id_res.get("bundle", {})
        evidence_items = gather_all_evidence_for_user(user_bundle)
        sys_acts = load_system_activity_for_user(user_bundle)
        timeline = build_chronological_timeline(c, sys_acts, evidence_items, audit_at)
        resource_states = reconstruct_resource_states(timeline, audit_at)

        status, steps = plan_case(c, user_bundle, timeline, resource_states, evidence_items)
        predictions[cid] = {
            "case_id": cid,
            "deletion_status": status,
            "steps": steps,
            "request_text": c.get("request_text", ""),
            "reported_status": c.get("reported_status", ""),
        }

    return predictions

# What: Loads the canonical ground truth answers from sample_output.csv.
# Why: Provides the official grading standard to measure accuracy against.
def load_ground_truth(sample_output_path="dataset/sample_output.csv"):
    path = Path(sample_output_path)
    ground_truth = {}

    with open(path, mode="r", encoding="utf-8", errors="replace") as f:
        reader = csv.DictReader(f)
        for row in reader:
            cid = row["case_id"]
            ground_truth[cid] = {
                "case_id": cid,
                "deletion_status": row["deletion_status"],
                "steps": json.loads(row["steps_json"]),
            }
    return ground_truth

# What: Calculates status accuracy, sequence accuracy, step accuracy, and field-level accuracies.
# Why: Produces the exact quantitative evaluation metrics required by the hackathon rubric.
def calculate_evaluation_metrics(predictions, ground_truth):
    total_cases = len(ground_truth)
    status_matches = 0
    sequence_matches = 0

    total_expected_steps = 0
    total_actual_steps = 0
    exact_step_matches = 0

    fields = ["phase", "system_id", "resource_id", "operation", "state", "evidence_id"]
    field_matches = {f: 0 for f in fields}
    field_totals = {f: 0 for f in fields}

    for cid, exp in ground_truth.items():
        pred = predictions.get(cid, {"deletion_status": "UNKNOWN", "steps": []})

        # 1. Status Match
        if pred["deletion_status"] == exp["deletion_status"]:
            status_matches += 1

        # 2. Sequence Match (status and exact array of steps)
        exp_steps = exp["steps"]
        pred_steps = pred["steps"]

        if pred["deletion_status"] == exp["deletion_status"] and pred_steps == exp_steps:
            sequence_matches += 1

        total_expected_steps += len(exp_steps)
        total_actual_steps += len(pred_steps)

        # 3. Step-level match (exact step dictionary match)
        for e_step in exp_steps:
            matched = any(
                e_step.get("phase") == p_step.get("phase") and
                e_step.get("system_id") == p_step.get("system_id") and
                e_step.get("resource_id") == p_step.get("resource_id") and
                e_step.get("operation") == p_step.get("operation") and
                e_step.get("state") == p_step.get("state") and
                e_step.get("evidence_id") == p_step.get("evidence_id")
                for p_step in pred_steps
            )
            if matched:
                exact_step_matches += 1

        # 4. Field-level matches across pairwise step alignments
        min_len = min(len(exp_steps), len(pred_steps))
        for i in range(min_len):
            e_s = exp_steps[i]
            p_s = pred_steps[i]
            for f in fields:
                field_totals[f] += 1
                if e_s.get(f) == p_s.get(f):
                    field_matches[f] += 1

    return {
        "total_cases": total_cases,
        "status_accuracy": (status_matches / total_cases) * 100 if total_cases else 0,
        "status_matches": status_matches,
        "sequence_accuracy": (sequence_matches / total_cases) * 100 if total_cases else 0,
        "sequence_matches": sequence_matches,
        "total_expected_steps": total_expected_steps,
        "total_actual_steps": total_actual_steps,
        "exact_step_matches": exact_step_matches,
        "step_accuracy": (exact_step_matches / total_expected_steps) * 100 if total_expected_steps else 0,
        "field_accuracies": {
            f: (field_matches[f] / field_totals[f]) * 100 if field_totals[f] else 0
            for f in fields
        },
        "field_counts": {
            f: (field_matches[f], field_totals[f])
            for f in fields
        }
    }

# What: Identifies and ranks the 5 worst cases based on discrepancies between expected and predicted steps.
# Why: Highlights the primary failure patterns so we know exactly what needs refinement.
def select_worst_5_cases(predictions, ground_truth):
    case_discrepancies = []

    for cid, exp in ground_truth.items():
        pred = predictions.get(cid, {"deletion_status": "UNKNOWN", "steps": []})

        exp_steps = exp["steps"]
        pred_steps = pred["steps"]
        exp_status = exp["deletion_status"]
        pred_status = pred["deletion_status"]

        # Discrepancy metric: status mismatch penalty + step length delta + field mismatches
        error_score = abs(len(exp_steps) - len(pred_steps))
        if exp_status != pred_status:
            error_score += 5

        min_len = min(len(exp_steps), len(pred_steps))
        for i in range(min_len):
            if exp_steps[i] != pred_steps[i]:
                error_score += 1

        case_discrepancies.append({
            "case_id": cid,
            "error_score": error_score,
            "expected_status": exp_status,
            "actual_status": pred_status,
            "expected_steps": exp_steps,
            "actual_steps": pred_steps,
            "request_text": pred.get("request_text", ""),
            "reported_status": pred.get("reported_status", ""),
        })

    # Sort descending by error score
    case_discrepancies.sort(key=lambda x: x["error_score"], reverse=True)
    return case_discrepancies[:5]

# What: Generates a clear side-by-side comparative diff of expected vs actual steps for a case.
# Why: Visualizes exact step omissions, unexpected additions, or attribute mismatches.
def format_step_diff(expected_steps, actual_steps):
    lines = []
    max_steps = max(len(expected_steps), len(actual_steps))

    header = f"{'Step':<5} | {'EXPECTED STEP':<46} | {'ACTUAL PREDICTED STEP':<46}"
    lines.append(header)
    lines.append("-" * len(header))

    for i in range(max_steps):
        exp_str = "[NONE]"
        act_str = "[NONE]"

        if i < len(expected_steps):
            s = expected_steps[i]
            exp_str = f"[{s.get('phase')[:4]}] {s.get('operation')} ({s.get('system_id')}/{s.get('resource_id')})"

        if i < len(actual_steps):
            s = actual_steps[i]
            act_str = f"[{s.get('phase')[:4]}] {s.get('operation')} ({s.get('system_id')}/{s.get('resource_id')})"

        match_tag = "==" if exp_str == act_str else "!="
        lines.append(f"{i+1:<5} | {exp_str:<46} {match_tag} {act_str:<46}")

    return "\n".join(lines)

# What: Explains the root cause of the difference between expected and actual steps for a specific case.
# Why: Provides deep engineering insight into what knowledge or multi-service link was missed.
def explain_why_it_differs(case_info):
    cid = case_info["case_id"]
    exp_steps = case_info["expected_steps"]
    act_steps = case_info["actual_steps"]

    explanations = {
        "case_11": (
            "WHY IT DIFFERS:\n"
            "- Multi-Service Resource Discovery: Expected 14 steps covering 4 distinct services "
            "(search_service, analytics_platform, support_platform, integration_service) in evidence_03.\n"
            "- Our current scanner only checked for primary account deletion and missed lingering data in "
            "search_052, analytics_2034, support_864, and active data_flow_9522.\n"
            "- Result: Falsely classified as COMPLETE instead of INCOMPLETE with a full remediation plan."
        ),
        "case_29": (
            "WHY IT DIFFERS:\n"
            "- Historical Email Resolution Across Services: The user changed their email before submitting deletion.\n"
            "- Expected 14 steps finding traces under both current and previous emails in export evidence_92 "
            "(search_1993, analytics_5208, support_5281, and active sync flow data_flow_3827).\n"
            "- Current scanner resolved identity but did not cross-reference all 4 secondary subsystems in evidence_92."
        ),
        "case_30": (
            "WHY IT DIFFERS:\n"
            "- Active Data Flow Omission: User warned that traces remain in search, support, and analytics.\n"
            "- Expected 14 steps identifying remaining search_9359, unredacted support_6477, un-anonymized analytics_3697, "
            "and active data_flow_8524 in evidence_92.\n"
            "- Current engine relied on workflow claim of COMPLETE and missed the un-synchronized data flow."
        ),
        "case_18": (
            "WHY IT DIFFERS:\n"
            "- Multi-Resource Verification Breadth: Expected 14 steps in evidence_94.\n"
            "- While our engine correctly flagged INCOMPLETE, it only planned 3 steps for the account resource, "
            "missing search_4013, analytics_037, support_5569, and active data_flow_4890.\n"
            "- In addition, expected verification steps must verify absence across all 4 affected services, not just account."
        ),
        "case_13": (
            "WHY IT DIFFERS:\n"
            "- Unchecked Secondary Services (Search & Support): Workflow reported NOT_STARTED.\n"
            "- Expected 8 steps finding remaining search_1308 and support_4218 in evidence_03, planning their deletion, "
            "and verifying absence along with retained security audit_record_4816.\n"
            "- Current engine falsely assumed COMPLETE with a single verification step."
        ),
    }

    return explanations.get(cid, "WHY IT DIFFERS: Complex multi-system evidence correlation required.")

# What: Runs the full evaluation report comparing sample predictions against ground truth.
# Why: Main entry point for Stage 7.
def run_evaluation_report():
    print("=" * 80)
    print("STAGE 7: COMPREHENSIVE EVALUATION REPORT (Sample Dataset vs Ground Truth)")
    print("=" * 80)

    print("\n1. Running predictions across all 32 sample deletion requests...")
    predictions = run_sample_predictions()
    ground_truth = load_ground_truth()

    print("2. Calculating accuracy metrics...\n")
    metrics = calculate_evaluation_metrics(predictions, ground_truth)

    print("=" * 80)
    print("ACCURACY SUMMARY REPORT")
    print("=" * 80)
    print(f"Total Sample Cases Evaluated : {metrics['total_cases']}")
    print(f"Status Accuracy              : {metrics['status_accuracy']:.2f}% ({metrics['status_matches']}/{metrics['total_cases']} cases)")
    print(f"Sequence Accuracy (Exact)    : {metrics['sequence_accuracy']:.2f}% ({metrics['sequence_matches']}/{metrics['total_cases']} cases)")
    print(f"Step-Level Match Accuracy    : {metrics['step_accuracy']:.2f}% ({metrics['exact_step_matches']}/{metrics['total_expected_steps']} expected steps)")
    print(f"Total Steps (Expected/Actual): {metrics['total_expected_steps']} expected vs {metrics['total_actual_steps']} actual")

    print("\nFIELD-LEVEL ACCURACY (On aligned steps):")
    print("-" * 50)
    for field, acc in metrics["field_accuracies"].items():
        matched, total = metrics["field_counts"][field]
        print(f"  Field '{field:<12}': {acc:6.2f}% ({matched}/{total})")

    print("\n" + "=" * 80)
    print("3. TOP 5 WORST CASES (Detailed Side-by-Side Diff & Explanations)")
    print("=" * 80)
    worst_cases = select_worst_5_cases(predictions, ground_truth)

    for rank, case_info in enumerate(worst_cases, start=1):
        cid = case_info["case_id"]
        exp_st = case_info["expected_status"]
        act_st = case_info["actual_status"]
        exp_s = case_info["expected_steps"]
        act_s = case_info["actual_steps"]

        print(f"\n[WORST CASE #{rank}] {cid}")
        print(f"User Request     : \"{case_info['request_text']}\"")
        print(f"Reported Workflow: {case_info['reported_status']}")
        print(f"Status Result    : Expected [{exp_st}] vs Actual [{act_st}]")
        print(f"Step Count       : Expected {len(exp_s)} steps vs Actual {len(act_s)} steps\n")

        print(format_step_diff(exp_s, act_s))
        print("\n" + explain_why_it_differs(case_info))
# What: Runs evaluation across the 3 custom extra test cases in evaluation/extra_cases/.
# Why: Validates edge cases (historical alias, non-deletion intent, misleading claims) and prints diffs.
def run_extra_cases_evaluation(extra_requests_path="evaluation/extra_cases/extra_deletion_requests.csv",
                               extra_output_path="evaluation/extra_cases/extra_expected_output.csv"):
    req_path = Path(extra_requests_path)
    out_path = Path(extra_output_path)

    if not req_path.exists() or not out_path.exists():
        print(f"Error: Missing extra test case files at {req_path} or {out_path}")
        return {}

    with open(req_path, mode="r", encoding="utf-8") as f:
        cases = list(csv.DictReader(f))

    ground_truth = {}
    with open(out_path, mode="r", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            cid = row["case_id"]
            ground_truth[cid] = {
                "case_id": cid,
                "deletion_status": row.get("deletion_status", ""),
                "steps": json.loads(row.get("steps_json", "[]"))
            }

    print("=" * 80)
    print("EXTRA EVALUATION TEST CASES REPORT (Edge Cases & Hostile Scenarios)")
    print("=" * 80)

    results = {}
    for c in cases:
        cid = c["case_id"]
        email = c["email"]
        audit_at = c["audit_at"]
        req_text = c.get("request_text", "")
        rep_status = c.get("reported_status", "")

        # Run through full audit pipeline
        id_res = resolve_identity(email)
        user_bundle = id_res.get("bundle", {})
        evidence_items = gather_all_evidence_for_user(user_bundle)
        sys_acts = load_system_activity_for_user(user_bundle)
        timeline = build_chronological_timeline(c, sys_acts, evidence_items, audit_at)
        resource_states = reconstruct_resource_states(timeline, audit_at)

        act_status, act_steps = plan_case(c, user_bundle, timeline, resource_states, evidence_items)

        gt = ground_truth.get(cid, {})
        exp_status = gt.get("deletion_status", "")
        exp_steps = gt.get("steps", [])

        # Calculate step match
        matched_steps = 0
        for es in exp_steps:
            for as_ in act_steps:
                if (es.get("phase") == as_.get("phase") and
                    es.get("system_id") == as_.get("system_id") and
                    es.get("resource_id") == as_.get("resource_id") and
                    es.get("operation") == as_.get("operation")):
                    matched_steps += 1
                    break

        total_exp = len(exp_steps)
        if total_exp == 0:
            step_pct = 100.0 if len(act_steps) == 0 else 0.0
        else:
            step_pct = (matched_steps / total_exp) * 100.0

        status_passed = (act_status == exp_status)
        is_exact = (status_passed and act_steps == exp_steps)

        results[cid] = {
            "case_id": cid,
            "email": email,
            "user_id": user_bundle.get("user_id", ""),
            "expected_status": exp_status,
            "actual_status": act_status,
            "status_passed": status_passed,
            "expected_steps": exp_steps,
            "actual_steps": act_steps,
            "step_match_pct": step_pct,
            "matched_steps_count": matched_steps,
            "total_expected_steps": total_exp,
            "is_exact_match": is_exact
        }

        print(f"\n--- [{cid}] ---")
        print(f"Query Email      : {email} (Resolved User: {user_bundle.get('user_id', 'UNKNOWN')})")
        print(f"User Request     : \"{req_text}\"")
        print(f"Reported Workflow: {rep_status}")
        print(f"Status Result    : Expected [{exp_status}] vs Actual [{act_status}] -> {'PASS' if status_passed else 'FAIL'}")
        print(f"Step Match       : {step_pct:6.2f}% ({matched_steps}/{total_exp} aligned steps matching)")

        if not is_exact:
            print("\nSTEP-LEVEL DIFF (Expected vs Actual):")
            print(format_step_diff(exp_steps, act_steps))
        else:
            print("Steps Result     : 100% PERFECT MATCH!")

    print("\n" + "=" * 80)
    return results

if __name__ == "__main__":
    if "--extra" in sys.argv:
        run_extra_cases_evaluation()
    else:
        run_evaluation_report()
