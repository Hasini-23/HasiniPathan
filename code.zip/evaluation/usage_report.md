# Evaluation Usage & Cost Report

## 1. Executive Summary

This report provides a complete accounting of LLM model invocations, input/output tokens, and financial expenditure incurred across the deletion request audit pipeline, derived directly from [`evaluation/usage_log.csv`](file:///Users/pathanhasini/untitled%20folder/untitled%20folder%202/evaluation/usage_log.csv).

| Metric | Measured Value | Benchmark Target | Status |
| :--- | :--- | :--- | :--- |
| **Total Multimodal Files Processed** | 15 files (4 PDFs, 11 PNGs) | 15 files | Complete |
| **Tier 1 Extraction Success Rate** | 100% (15 / 15 files) | > 80% | Passed |
| **Tier 2 LLM Fallback Calls** | 0 calls | As needed | Optimal |
| **Total Input Tokens** | 0 tokens | Tracked | Optimal |
| **Total Output Tokens** | 0 tokens | Tracked | Optimal |
| **Total Cost (USD)** | **$0.00** | Budget Cap | **Zero Cost** |

---

## 2. Extraction Pipeline Architecture

The audit agent implements a strict **two-tier multimodal processing pipeline** designed to eliminate unnecessary LLM operational costs and external latency:

```
                      Raw Evidence Asset
                     (PDF Document / PNG)
                              |
                              v
                  [ Tier 1: Local Extraction ]
             /                                     \
            v                                       v
    PDF Documents                                PNG Images
 (Adobe Stream Decoding)                   (Native Apple Vision OCR)
   base64.a85decode()                         bin/ocr subprocess
   zlib.decompress()                       VNRecognizeTextRequest
            \                                       /
             +------------------+------------------+
                                |
                    Did Extraction Succeed?
                    (char_count >= 10 chars)
                     /                    \
                   YES                     NO
                   /                        \
                  v                          v
          [ Cache Result ]        [ Tier 2: LLM Fallback ]
        cache/<file_id>.txt         Gemini 1.5 Pro multimodal
        cache/<file_id>.json         Log tokens & USD cost to
                                    evaluation/usage_log.csv
```

---

## 3. Per-File Extraction & Resource Accounting

| File ID | File Name | File Type | Extraction Method | Chars Extracted | LLM Model | Tokens (In / Out) | Cost (USD) |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `evidence_04` | `account_admin_console_20260926.png` | PNG Image | Native OCR (`bin/ocr`) | 1,053 | None (Tier 1) | 0 / 0 | $0.00 |
| `evidence_09` | `search_index_inspector_20260901.png` | PNG Image | Native OCR (`bin/ocr`) | 1,006 | None (Tier 1) | 0 / 0 | $0.00 |
| `evidence_14` | `connector_management_console_20260807.png` | PNG Image | Native OCR (`bin/ocr`) | 1,213 | None (Tier 1) | 0 / 0 | $0.00 |
| `evidence_18` | `account_history_report_20260718.pdf` | PDF Document | Stream Decompress (`zlib`) | 717 | None (Tier 1) | 0 / 0 | $0.00 |
| `evidence_19` | `analytics_profile_view_20260713.png` | PNG Image | Native OCR (`bin/ocr`) | 1,195 | None (Tier 1) | 0 / 0 | $0.00 |
| `evidence_23` | `customer_export_console_20260618.png` | PNG Image | Native OCR (`bin/ocr`) | 1,203 | None (Tier 1) | 0 / 0 | $0.00 |
| `evidence_27` | `legal_retention_register_20260529.pdf` | PDF Document | Stream Decompress (`zlib`) | 1,001 | None (Tier 1) | 0 / 0 | $0.00 |
| `evidence_28` | `support_ticket_console_20260524.png` | PNG Image | Native OCR (`bin/ocr`) | 1,198 | None (Tier 1) | 0 / 0 | $0.00 |
| `evidence_32` | `backup_restore_console_20260429.png` | PNG Image | Native OCR (`bin/ocr`) | 1,353 | None (Tier 1) | 0 / 0 | $0.00 |
| `evidence_37` | `security_audit_explorer_20260905.png` | PNG Image | Native OCR (`bin/ocr`) | 1,306 | None (Tier 1) | 0 / 0 | $0.00 |
| `evidence_42` | `deleted_account_reference_20260310.png` | PNG Image | Native OCR (`bin/ocr`) | 1,207 | None (Tier 1) | 0 / 0 | $0.00 |
| `evidence_46` | `object_storage_browser_20260213.png` | PNG Image | Native OCR (`bin/ocr`) | 1,398 | None (Tier 1) | 0 / 0 | $0.00 |
| `evidence_55` | `security_retention_extract.pdf` | PDF Document | Stream Decompress (`zlib`) | 618 | None (Tier 1) | 0 / 0 | $0.00 |
| `evidence_58` | `delivery_correction_attachment.pdf` | PDF Document | Stream Decompress (`zlib`) | 836 | None (Tier 1) | 0 / 0 | $0.00 |
| `evidence_60` | `marketing_profile_console.png` | PNG Image | Native OCR (`bin/ocr`) | 1,180 | None (Tier 1) | 0 / 0 | $0.00 |
| **TOTALS** | **15 Evidence Files** | — | — | **16,484** | — | **0 / 0** | **$0.00** |

---

## 4. Cost and Token Metrics per Request

Across the 518 customer deletion requests evaluated by the system:
- **Average LLM Calls per Request:** `0.0`
- **Average Tokens per Request:** `0.0`
- **Average Latency Overhead per Request:** `< 0.002s` (via disk cache in `cache/`)
- **Cost per Request:** `$0.000000 USD`

### Audit Trail Verification
The underlying usage tracking log is maintained in [`evaluation/usage_log.csv`](file:///Users/pathanhasini/untitled%20folder/untitled%20folder%202/evaluation/usage_log.csv) with column headers:
`timestamp,file_id,file_name,model_name,input_tokens,output_tokens,cost_usd`.
Any future unparsed files requiring model fallback will automatically append timestamped token counts and dollar amounts to this log.
