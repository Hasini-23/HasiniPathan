import csv
import json
import os
from pathlib import Path

# What: Inspects all CSV files in a given directory.
# Why: Allows us to inspect headers, row counts, and data samples dynamically without making assumptions about schema.
def inspect_all_csvs(dataset_dir):
    dataset_path = Path(dataset_dir)
    csv_files = sorted(dataset_path.glob("*.csv"))

    print("=" * 80)
    print(f"1. CSV FILES INSPECTION (Found {len(csv_files)} files)")
    print("=" * 80)

    for csv_file in csv_files:
        print(f"\n--- File: {csv_file.name} ---")
        with open(csv_file, mode="r", encoding="utf-8", errors="replace") as f:
            reader = csv.reader(f)
            try:
                headers = next(reader)
            except StopIteration:
                print("  [Empty File]")
                continue

            row_count = 0
            for _ in reader:
                row_count += 1

        print(f"Total Rows : {row_count}")
        print(f"Columns ({len(headers)}): {headers}")

        # Fetch 3 sample rows as dictionaries
        samples = []
        with open(csv_file, mode="r", encoding="utf-8", errors="replace") as f:
            dict_reader = csv.DictReader(f)
            for row in dict_reader:
                samples.append(row)
                if len(samples) == 3:
                    break

        print("Sample Rows (up to 3):")
        for i, sample in enumerate(samples, 1):
            print(f"  Row {i}: {sample}")

# What: Discovers and groups every evidence file by its extension.
# Why: Helps us know all formats present in dataset/evidence/ (e.g. logs, SQL, JSON, PDFs, PNGs).
def group_evidence_by_extension(evidence_dir):
    evidence_path = Path(evidence_dir)
    grouped = {}

    if not evidence_path.exists():
        return grouped

    for file_path in evidence_path.rglob("*"):
        if file_path.is_file() and not file_path.name.startswith("."):
            ext = file_path.suffix.lower() if file_path.suffix else "[no_ext]"
            grouped.setdefault(ext, []).append(file_path)

    # Sort files within each extension group
    for ext in grouped:
        grouped[ext].sort()

    return grouped

# What: Opens and displays a realistic preview of an evidence file based on its type.
# Why: Lets us see whether it contains structured text, queries, log entries, or binary data.
def preview_evidence_file(file_path):
    path = Path(file_path)
    file_size = path.stat().st_size
    ext = path.suffix.lower()

    print(f"\n[Preview] {path.name} ({ext}, {file_size} bytes)")
    print(f"Path: {path}")

    # Text formats: JSON, LOG, SQL, TXT
    if ext in [".json", ".log", ".sql", ".txt"]:
        with open(path, mode="r", encoding="utf-8", errors="replace") as f:
            lines = [f.readline() for _ in range(6)]
            preview_text = "".join(lines).strip()
            print("Content Snippet (first few lines):")
            print(preview_text)
    # Binary formats: PDF, PNG, etc.
    else:
        with open(path, mode="rb") as f:
            header_bytes = f.read(16)
        print("Binary File detected (raw bytes / document image).")
        print(f"Magic / Header Bytes: {header_bytes!r}")

# What: Explains the relationship and linking keys between dataset files.
# Why: Connects individual CSV tables into a clear mental model before building the audit logic.
def explain_file_connections():
    print("\n" + "=" * 80)
    print("3. HOW THE FILES CONNECT TO EACH OTHER")
    print("=" * 80)
    connections = """
1. deletion_requests.csv:
   - Starting point of audit cases.
   - Links to user_identities.csv via `email`.
   - Each row has `case_id`, `email`, `requested_at`, `reported_status`, and `audit_at`.

2. user_identities.csv:
   - Resolves a user's current identity.
   - Primary key is `user_id`.
   - Contains: `user_id`, `name`, `email`, `phone`, `email_hash`.

3. user_audit_log.csv:
   - Historical profile changes (e.g., previous emails or phone numbers).
   - Links to user_identities.csv via `user_id`.
   - If a user changed their email, this log links the old email to their `user_id`.

4. system_activity.csv:
   - Operational events (deletions, indexing, backups, data flows, syncs).
   - Contains `resource_id` (e.g., account IDs, search doc IDs) and timestamps.
   - Shows what systems claimed to do regarding user records before `audit_at`.

5. deletion_rules.csv:
   - The compliance policy table.
   - Specifies `data_category`, `condition`, and `required_action` (DELETE, REDACT, ANONYMIZE).

6. evidence_files.csv & dataset/evidence/:
   - `evidence_files.csv` is a manifest linking `file_id` to actual paths in `dataset/evidence/`.
   - The files in `dataset/evidence/` (JSON, SQL, logs, PDFs, PNGs) contain the ground truth
     state of user records across systems at `audit_at`.

7. output.csv:
   - The final submission template: `case_id`, `deletion_status`, `steps_json`.
"""
    print(connections.strip())

# What: Runs the full inspection of dataset CSVs, evidence files, and file connections.
# Why: Main execution function for Stage 1 dataset inspection.
def run_inspection():
    dataset_dir = Path("dataset")
    evidence_dir = dataset_dir / "evidence"

    # Step 1: Inspect all CSVs
    inspect_all_csvs(dataset_dir)

    # Step 2: Group and list all evidence files
    print("\n" + "=" * 80)
    print("2. EVIDENCE FILES GROUPED BY EXTENSION")
    print("=" * 80)
    grouped_evidence = group_evidence_by_extension(evidence_dir)

    for ext, files in sorted(grouped_evidence.items()):
        print(f"\nExtension {ext} ({len(files)} files):")
        for f in files:
            print(f"  - {f.relative_to(dataset_dir)}")

    # Step 3: Open and preview one sample file of each extension
    print("\n" + "=" * 80)
    print("PREVIEWS OF ONE SAMPLE FILE PER EXTENSION")
    print("=" * 80)
    for ext, files in sorted(grouped_evidence.items()):
        if files:
            preview_evidence_file(files[0])

    # Step 4: Explain relationships
    explain_file_connections()
    print("=" * 80)

if __name__ == "__main__":
    run_inspection()
