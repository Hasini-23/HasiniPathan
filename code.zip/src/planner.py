import csv
import json
import re
import sys
from pathlib import Path

# Ensure project root is on sys.path so direct execution works seamlessly
ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from src.identity import resolve_identity
from src.intent import wants_deletion
from src.evidence import (
    load_evidence_manifest,
    gather_all_evidence_for_user,
    get_canonical_system_id,
)
from src.state import (
    load_system_activity_for_user,
    build_chronological_timeline,
    reconstruct_resource_states,
)
from src.rules import audit_case_findings

# Official Phase Order specified in problem statement
PHASE_ORDER = {
    "FINDING": 0,
    "REMEDIATION": 1,
    "VERIFICATION": 2,
}

# Official Operation Order within each phase from the problem statement table
OPERATION_ORDER = {
    "FINDING": {
        "REPORT_REMAINING_RECORD": 0,
        "REPORT_EXPOSED_PII": 1,
        "REPORT_ACTIVE_DATA_FLOW": 2,
        "REPORT_RESTORE_RISK": 3,
    },
    "REMEDIATION": {
        "DISABLE_DATA_FLOW": 0,
        "BLOCK_RESTORE": 1,
        "DELETE_RECORD": 2,
        "REDACT_RECORD": 3,
        "ANONYMIZE_RECORD": 4,
    },
    "VERIFICATION": {
        "VERIFY_RECORD_ABSENT": 0,
        "VERIFY_RECORD_PRESENT": 1,
        "VERIFY_RECORD_REDACTED": 2,
        "VERIFY_RECORD_ANONYMIZED": 3,
        "VERIFY_DATA_FLOW_DISABLED": 4,
        "VERIFY_RESTORE_BLOCKED": 5,
    },
}

# What: Generates the sort key tuple for sorting audit steps according to hackathon rules.
# Why: Guarantees strict ordering: phase -> operation order -> system_id -> resource_id.
def get_step_sort_key(step):
    phase = step.get("phase", "")
    op = step.get("operation", "")
    sys_id = step.get("system_id", "")
    res_id = step.get("resource_id", "")

    phase_rank = PHASE_ORDER.get(phase, 99)
    op_rank = OPERATION_ORDER.get(phase, {}).get(op, 99)

    return (phase_rank, op_rank, sys_id, res_id)

# What: Sorts a list of step dictionaries strictly by Phase, Operation, system_id, and resource_id.
# Why: Implements the required sort_steps() function and re-indexes step_no consecutively starting at 1.
def sort_steps(steps):
    if not steps:
        return []

    sorted_list = sorted(steps, key=get_step_sort_key)

    # Reassign step_no consecutively starting from 1
    for idx, s in enumerate(sorted_list, start=1):
        s["step_no"] = idx

    return sorted_list

# What: Derives corresponding remediation and verification actions for a given finding.
# Why: Transforms audit findings into the ordered remediation plan and subsequent verification checks.
def plan_remediation_and_verification_for_finding(finding):
    op = finding["operation"]
    sys_id = finding["system_id"]
    res_id = finding["resource_id"]

    remediation = None
    verification = None

    if op == "REPORT_REMAINING_RECORD":
        remediation = {
            "phase": "REMEDIATION",
            "system_id": sys_id,
            "resource_id": res_id,
            "operation": "DELETE_RECORD",
            "state": "ABSENT",
            "evidence_id": "",
        }
        verification = {
            "phase": "VERIFICATION",
            "system_id": sys_id,
            "resource_id": res_id,
            "operation": "VERIFY_RECORD_ABSENT",
            "state": "ABSENT",
            "evidence_id": "",
        }
    elif op == "REPORT_EXPOSED_PII":
        if "analytics" in res_id or sys_id == "analytics_platform":
            remediation = {
                "phase": "REMEDIATION",
                "system_id": sys_id,
                "resource_id": res_id,
                "operation": "ANONYMIZE_RECORD",
                "state": "ANONYMIZED",
                "evidence_id": "",
            }
            verification = {
                "phase": "VERIFICATION",
                "system_id": sys_id,
                "resource_id": res_id,
                "operation": "VERIFY_RECORD_ANONYMIZED",
                "state": "ANONYMIZED",
                "evidence_id": "",
            }
        else:
            remediation = {
                "phase": "REMEDIATION",
                "system_id": sys_id,
                "resource_id": res_id,
                "operation": "REDACT_RECORD",
                "state": "REDACTED",
                "evidence_id": "",
            }
            verification = {
                "phase": "VERIFICATION",
                "system_id": sys_id,
                "resource_id": res_id,
                "operation": "VERIFY_RECORD_REDACTED",
                "state": "REDACTED",
                "evidence_id": "",
            }
    elif op == "REPORT_ACTIVE_DATA_FLOW":
        remediation = {
            "phase": "REMEDIATION",
            "system_id": sys_id,
            "resource_id": res_id,
            "operation": "DISABLE_DATA_FLOW",
            "state": "DISABLED",
            "evidence_id": "",
        }
        verification = {
            "phase": "VERIFICATION",
            "system_id": sys_id,
            "resource_id": res_id,
            "operation": "VERIFY_DATA_FLOW_DISABLED",
            "state": "DISABLED",
            "evidence_id": "",
        }
    elif op == "REPORT_RESTORE_RISK":
        remediation = {
            "phase": "REMEDIATION",
            "system_id": sys_id,
            "resource_id": res_id,
            "operation": "BLOCK_RESTORE",
            "state": "BLOCKED",
            "evidence_id": "",
        }
        verification = {
            "phase": "VERIFICATION",
            "system_id": sys_id,
            "resource_id": res_id,
            "operation": "VERIFY_RESTORE_BLOCKED",
            "state": "BLOCKED",
            "evidence_id": "",
        }

    return remediation, verification

# What: Generates the full plan of steps for a case based on intent, timeline, and findings.
# Why: Determines deletion_status (COMPLETE, INCOMPLETE, or NOT_APPLICABLE) and assembles valid steps_json.
def plan_case(case_row, user_bundle, timeline, resource_states, evidence_items):
    req_text = case_row.get("request_text", "")
    audit_at = case_row.get("audit_at", "")

    # 1. Non-deletion requests -> NOT_APPLICABLE
    if not wants_deletion(req_text):
        return "NOT_APPLICABLE", []

    # 2. Check for findings
    raw_findings = audit_case_findings(case_row, user_bundle, timeline, resource_states, evidence_items)

    # Pick the most relevant evidence_id captured on or before audit_at for this case
    case_evidence_id = "evidence_54"
    valid_evs = [ev for ev in evidence_items if not audit_at or ev["captured_at"] <= audit_at]
    if valid_evs:
        case_evidence_id = valid_evs[-1]["file_id"]

    # 3. Discover primary account resource ID from evidence content wherever it exists
    user_id = user_bundle.get("user_id", "")
    discovered_account_res = None

    # First check evidence items directly
    for ev in evidence_items:
        r_id = ev.get("resource_id", "")
        if r_id.startswith("account_") and r_id not in ("account", "unknown_resource"):
            discovered_account_res = r_id
            break
        detail = ev.get("detail") or {}
        rec = detail.get("record") if isinstance(detail, dict) else None
        if isinstance(rec, dict):
            rec_res = str(rec.get("resource_id") or "").strip()
            if rec_res.startswith("account_") and rec_res not in ("account", "unknown_resource"):
                discovered_account_res = rec_res
                break
        if isinstance(detail, dict) and "content" in detail:
            m_acc = re.search(r"\b(account_\d+)\b", str(detail["content"]))
            if m_acc:
                discovered_account_res = m_acc.group(1)
                break

    # Next check resource states
    if not discovered_account_res:
        for r_id, s_info in resource_states.items():
            if (s_info.get("system_id") == "account_service" or r_id.startswith("account_")) and r_id not in ("account", "unknown_resource"):
                discovered_account_res = r_id
                break

    if discovered_account_res:
        account_res = discovered_account_res
    elif user_id and "_" in user_id:
        try:
            num = int(user_id.split("_")[1])
            account_res = f"account_{num:03d}"
        except ValueError:
            account_res = f"account_{user_id}"
    else:
        account_res = "account"

    # 4. If findings exist -> INCOMPLETE
    if raw_findings:
        all_steps = []
        for f in raw_findings:
            sys_id = get_canonical_system_id(f.get("system_id"), f.get("resource_id"))
            res_id = f.get("resource_id", "")
            finding_step = {
                "phase": "FINDING",
                "system_id": sys_id,
                "resource_id": res_id,
                "operation": f["operation"],
                "state": f["state"],
                "evidence_id": f["evidence_id"] or case_evidence_id,
            }
            all_steps.append(finding_step)

            remediation, verification = plan_remediation_and_verification_for_finding(f)
            if remediation:
                remediation["system_id"] = get_canonical_system_id(remediation.get("system_id"), remediation.get("resource_id"))
                all_steps.append(remediation)
            if verification:
                verification["system_id"] = get_canonical_system_id(verification.get("system_id"), verification.get("resource_id"))
                all_steps.append(verification)

        # Primary account verification is always included
        all_steps.append({
            "phase": "VERIFICATION",
            "system_id": "account_service",
            "resource_id": account_res,
            "operation": "VERIFY_RECORD_ABSENT",
            "state": "ABSENT",
            "evidence_id": "",
        })

        # Include retained security audit records
        for r_id, s_info in resource_states.items():
            if r_id.startswith("audit_record_"):
                all_steps.append({
                    "phase": "VERIFICATION",
                    "system_id": "security_service",
                    "resource_id": r_id,
                    "operation": "VERIFY_RECORD_PRESENT",
                    "state": "PRESENT",
                    "evidence_id": "",
                })

        sorted_steps = sort_steps(all_steps)
        return "INCOMPLETE", sorted_steps

    # 5. If no findings exist -> COMPLETE
    verification_steps = []
    verification_steps.append({
        "phase": "VERIFICATION",
        "system_id": "account_service",
        "resource_id": account_res,
        "operation": "VERIFY_RECORD_ABSENT",
        "state": "ABSENT",
        "evidence_id": case_evidence_id,
    })

    # Include all other verified compliant resources
    for r_id, s_info in resource_states.items():
        if r_id == account_res or r_id in ("account", "unknown_resource") or "ord-" in r_id.lower() or "legal_hold" in r_id.lower():
            continue
        sys_id = s_info.get("system_id") or ""
        st = s_info.get("final_state")
        ev_id = s_info.get("evidence_id") or case_evidence_id

        if not sys_id:
            if "audit_record" in r_id:
                sys_id = "security_service"
            elif "support" in r_id:
                sys_id = "support_platform"
            elif "analytics" in r_id:
                sys_id = "analytics_platform"
            elif "data_flow" in r_id:
                sys_id = "integration_service"
            elif "backup" in r_id:
                sys_id = "backup_service"
            elif "tombstone" in r_id:
                sys_id = "identity_service"
            elif "search" in r_id:
                sys_id = "search_service"

        op = "VERIFY_RECORD_ABSENT"
        if "audit_record" in r_id:
            op = "VERIFY_RECORD_PRESENT"
            st = "PRESENT"
            sys_id = "security_service"
        elif sys_id == "support_platform":
            op = "VERIFY_RECORD_REDACTED"
            st = "REDACTED"
        elif sys_id == "analytics_platform":
            op = "VERIFY_RECORD_ANONYMIZED"
            st = "ANONYMIZED"
        elif sys_id == "integration_service":
            op = "VERIFY_DATA_FLOW_DISABLED"
            st = "DISABLED"
        elif sys_id == "backup_service":
            op = "VERIFY_RESTORE_BLOCKED"
            st = "BLOCKED"
        elif sys_id == "identity_service":
            op = "VERIFY_RECORD_REDACTED"
            st = "REDACTED"

        verification_steps.append({
            "phase": "VERIFICATION",
            "system_id": sys_id,
            "resource_id": r_id,
            "operation": op,
            "state": st,
            "evidence_id": ev_id,
        })

    sorted_steps = sort_steps(verification_steps)
    return "COMPLETE", sorted_steps

# What: Processes all 518 cases from deletion_requests.csv, sorts them, and writes output.csv.
# Why: Produces the final hackathon submission file containing exactly 518 validated rows.
def generate_output_csv(input_csv="dataset/deletion_requests.csv", output_csv_path="output.csv"):
    input_path = Path(input_csv)
    if not input_path.exists():
        raise FileNotFoundError(f"Input file {input_csv} does not exist.")

    cases = []
    with open(input_path, mode="r", encoding="utf-8", errors="replace") as f:
        cases = list(csv.DictReader(f))

    # Sort cases numerically by case_id: case_33, case_34, ..., case_550
    cases.sort(key=lambda x: int(x["case_id"].split("_")[1]))

    output_rows = []
    for c in cases:
        cid = c["case_id"]
        email = c["email"]
        audit_at = c["audit_at"]

        # Run pipeline
        id_res = resolve_identity(email)
        user_bundle = id_res.get("bundle", {})
        evidence_items = gather_all_evidence_for_user(user_bundle)
        sys_acts = load_system_activity_for_user(user_bundle)
        timeline = build_chronological_timeline(c, sys_acts, evidence_items, audit_at)
        resource_states = reconstruct_resource_states(timeline, audit_at)

        status, steps = plan_case(c, user_bundle, timeline, resource_states, evidence_items)

        output_rows.append({
            "case_id": cid,
            "deletion_status": status,
            "steps_json": json.dumps(steps, separators=(",", ":")),
        })

    # Write output to output_csv_path and dataset/output.csv
    for out_path_str in [output_csv_path, "dataset/output.csv"]:
        out_p = Path(out_path_str)
        with open(out_p, mode="w", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=["case_id", "deletion_status", "steps_json"])
            writer.writeheader()
            for row in output_rows:
                writer.writerow(row)

    return output_rows

# What: Reads back output.csv and rigorously validates the 518 row count, headers, and JSON syntax.
# Why: Confirms zero parsing errors or invalid formatting before submission.
def validate_output_file(output_csv_path="output.csv"):
    path = Path(output_csv_path)
    if not path.exists():
        return False, "Output file does not exist."

    with open(path, mode="r", encoding="utf-8", errors="replace") as f:
        reader = csv.DictReader(f)
        headers = reader.fieldnames

        if headers != ["case_id", "deletion_status", "steps_json"]:
            return False, f"Invalid headers: {headers}"

        rows = list(reader)
        if len(rows) != 518:
            return False, f"Invalid row count: expected 518, got {len(rows)}"

        for idx, row in enumerate(rows, start=1):
            cid = row.get("case_id", "")
            status = row.get("deletion_status", "")
            steps_raw = row.get("steps_json", "")

            if not cid or not status:
                return False, f"Row {idx} is missing case_id or deletion_status."

            if status not in ("COMPLETE", "INCOMPLETE", "NOT_APPLICABLE"):
                return False, f"Row {idx} ({cid}) has invalid status '{status}'."

            try:
                parsed_steps = json.loads(steps_raw)
                if not isinstance(parsed_steps, list):
                    return False, f"Row {idx} ({cid}) steps_json is not a JSON array."
                if status == "NOT_APPLICABLE" and parsed_steps != []:
                    return False, f"Row {idx} ({cid}) is NOT_APPLICABLE but steps_json is not []."
            except json.JSONDecodeError as err:
                return False, f"Row {idx} ({cid}) contains invalid JSON: {err}"

    return True, f"Successfully validated {len(rows)} rows with valid JSON."

# What: Main execution function for Stage 6 to test sort_steps, generate output.csv, and validate.
# Why: Coordinates and prints all Stage 6 outputs clearly for the user.
def run_stage_6_demo():
    print("=" * 80)
    print("STAGE 6: PLANNER & OUTPUT.CSV GENERATION")
    print("=" * 80)

    # 1. Test sort_steps()
    print("\n--- 1. TESTING sort_steps() FUNCTION ---")
    test_steps = [
        {"step_no": 99, "phase": "VERIFICATION", "operation": "VERIFY_RECORD_ABSENT", "system_id": "account_service", "resource_id": "account_001", "state": "ABSENT", "evidence_id": "evidence_54"},
        {"step_no": 99, "phase": "FINDING", "operation": "REPORT_REMAINING_RECORD", "system_id": "account_service", "resource_id": "account_001", "state": "PRESENT", "evidence_id": "evidence_54"},
        {"step_no": 99, "phase": "REMEDIATION", "operation": "DELETE_RECORD", "system_id": "account_service", "resource_id": "account_001", "state": "ABSENT", "evidence_id": ""},
    ]
    sorted_test = sort_steps(test_steps)
    print("Input: [VERIFICATION, FINDING, REMEDIATION]")
    print(f"Output Phase Order: {[s['phase'] for s in sorted_test]}")
    print(f"Consecutive Step Numbers: {[s['step_no'] for s in sorted_test]}")
    assert [s["phase"] for s in sorted_test] == ["FINDING", "REMEDIATION", "VERIFICATION"]
    assert [s["step_no"] for s in sorted_test] == [1, 2, 3]
    print("sort_steps() test PASSED!")

    # 2. Generate output.csv for all 518 cases
    print("\n--- 2. GENERATING output.csv FOR ALL 518 CASES ---")
    output_rows = generate_output_csv()
    print(f"Generated {len(output_rows)} rows in output.csv.")

    # 3. Validate output.csv
    print("\n--- 3. VALIDATING output.csv ---")
    is_valid, message = validate_output_file("output.csv")
    print(f"Validation Status: {'PASS' if is_valid else 'FAIL'}")
    print(f"Validation Detail: {message}")

    # 4. Show summary statistics
    status_counts = {}
    for r in output_rows:
        status_counts[r["deletion_status"]] = status_counts.get(r["deletion_status"], 0) + 1
    print(f"\nStatus Distribution across 518 cases: {status_counts}")

    # 5. Display 5 sample rows from output.csv
    print("\n--- 4. SAMPLE ROWS FROM output.csv ---")
    for r in output_rows[:5]:
        print(f"Case: {r['case_id']:<10} | Status: {r['deletion_status']:<15} | Steps: {r['steps_json']}")

    # Also display one NOT_APPLICABLE case
    print("\nSample NOT_APPLICABLE row:")
    for r in output_rows:
        if r["deletion_status"] == "NOT_APPLICABLE":
            print(f"Case: {r['case_id']:<10} | Status: {r['deletion_status']:<15} | Steps: {r['steps_json']}")
            break

    print("=" * 80)

if __name__ == "__main__":
    run_stage_6_demo()
