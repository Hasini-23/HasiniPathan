# Extra Evaluation Cases Description

This directory contains 3 additional evaluation cases designed from real rows in `dataset/` to test edge-case behaviors: historical identity resolution, non-deletion intent discrimination, and skepticism toward misleading workflow completion claims.

---

### Case 1: `case_extra_01` (Old Email Resolution)
- **Source Case:** `case_12` (User `user_12`, Min-jun Kim).
- **What I Changed:** Substituted the query email with the user's historical email `minjun.kim90@gmail.com` (found in `dataset/user_audit_log.csv` row `audit_282` where `old_value = "minjun.kim90@gmail.com"` and `new_value = "minjun.kim@gmail.com"`). Maintained the original `request_text`, timestamps, and reported status.
- **What I Expect:** The identity resolution engine recognizes `minjun.kim90@gmail.com` as a historical alias for `user_12`, extracts the complete identity bundle (including current email, historical email, and hashes), and produces the same `INCOMPLETE` status and steps as `case_12` in `sample_output.csv`.
- **What It Tests:** Robustness of multi-hop historical identifier resolution when a customer submits a deletion request using an old, superseded email address.

---

### Case 2: `case_extra_02` (Non-Deletion Intent)
- **Source Case:** `case_01` (User `user_01`, Amina El-Masri).
- **What I Changed:** Replaced the request text with `"Please update my shipping address."`, while retaining all other fields.
- **What I Expect:** Deletion status `NOT_APPLICABLE` and an empty steps array `[]`.
- **What It Tests:** Precision of the intent classification engine to reject routine customer service inquiries (e.g. shipping address changes) and prevent accidental deletion workflows.

---

### Case 3: `case_extra_03` (Misleading Workflow Status)
- **Source Case:** `case_09` (User `user_09`, Kofi Appiah).
- **What I Changed:** In `dataset/sample_deletion_requests.csv`, `case_09` had `reported_status = "NOT_STARTED"`. In `case_extra_03`, we set `reported_status = "COMPLETE"`.
- **What I Expect:** Status remains `INCOMPLETE`, generating the exact same 5 remediation and verification steps as `case_09`.
- **What It Tests:** Auditor skepticism: verifying that the audit engine does not take claimed success (`reported_status: COMPLETE`) at face value, but instead reconstructs truth from raw evidence snapshots (detecting unblocked restore paths in `backup_service`).
