import csv
import os
from pathlib import Path

# What: Finds and lists all files inside the dataset directory.
# Why: We must dynamically discover available files instead of hardcoding filenames.
def get_dataset_files(dataset_dir):
    dataset_path = Path(dataset_dir)
    if not dataset_path.exists():
        return []
    # Return sorted list of file paths (ignoring hidden files like .DS_Store)
    return sorted([p for p in dataset_path.iterdir() if not p.name.startswith(".")])

# What: Extracts headers and total row count from a CSV file.
# Why: Allows us to inspect column names and dataset size without assuming any schema in advance.
def inspect_csv_schema(file_path):
    path = Path(file_path)
    with open(path, mode="r", encoding="utf-8", errors="replace") as f:
        reader = csv.reader(f)
        try:
            headers = next(reader)
        except StopIteration:
            return {"file_name": path.name, "headers": [], "row_count": 0}

        row_count = 0
        for _ in reader:
            row_count += 1

    return {
        "file_name": path.name,
        "headers": headers,
        "row_count": row_count,
    }

# What: Reads the first few data rows of a CSV file as dictionaries.
# Why: Lets us see real sample data values for each column without modifying the file.
def get_csv_samples(file_path, num_samples=3):
    path = Path(file_path)
    samples = []
    with open(path, mode="r", encoding="utf-8", errors="replace") as f:
        reader = csv.DictReader(f)
        for row in reader:
            samples.append(row)
            if len(samples) >= num_samples:
                break
    return samples

# What: Scans the evidence folder and counts files by their file extension.
# Why: Tells us what types of evidence files (e.g. .json, .sql, .log) we have to inspect later.
def summarize_evidence_directory(evidence_dir):
    evidence_path = Path(evidence_dir)
    if not evidence_path.exists():
        return {"total_files": 0, "by_extension": {}}

    extension_counts = {}
    total_files = 0

    for file_path in evidence_path.rglob("*"):
        if file_path.is_file() and not file_path.name.startswith("."):
            ext = file_path.suffix.lower() if file_path.suffix else "[no extension]"
            extension_counts[ext] = extension_counts.get(ext, 0) + 1
            total_files += 1

    return {
        "total_files": total_files,
        "by_extension": extension_counts
    }
