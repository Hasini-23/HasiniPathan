import csv
from pathlib import Path

# What: Normalizes an email string by trimming whitespace and converting to lowercase.
# Why: Guarantees consistent comparisons regardless of casing or accidental padding in user input.
def normalize_email(email_str):
    if not email_str:
        return ""
    return email_str.strip().lower()

# What: Loads current user identities from user_identities.csv into memory.
# Why: Enables fast lookup of current user profile information by user_id and email.
def load_user_identities(identities_csv_path):
    users_by_id = {}
    users_by_email = {}

    path = Path(identities_csv_path)
    if not path.exists():
        return users_by_id, users_by_email

    with open(path, mode="r", encoding="utf-8", errors="replace") as f:
        reader = csv.DictReader(f)
        for row in reader:
            user_id = row["user_id"].strip()
            email = normalize_email(row.get("email", ""))

            user_record = {
                "user_id": user_id,
                "name": row.get("name", "").strip(),
                "email": email,
                "phone": row.get("phone", "").strip(),
                "email_hash": row.get("email_hash", "").strip(),
                "updated_at": row.get("updated_at", "").strip(),
            }
            users_by_id[user_id] = user_record
            users_by_email.setdefault(email, []).append(user_id)

    return users_by_id, users_by_email

# What: Loads historical audit events from user_audit_log.csv into memory.
# Why: Allows us to trace changes in email, phone, or email_hash and find users who requested deletion with an old email.
def load_user_audit_log(audit_csv_path):
    audit_by_user = {}
    email_to_users = {}

    path = Path(audit_csv_path)
    if not path.exists():
        return audit_by_user, email_to_users

    with open(path, mode="r", encoding="utf-8", errors="replace") as f:
        reader = csv.DictReader(f)
        for row in reader:
            user_id = row["user_id"].strip()
            field_name = row.get("field_name", "").strip()
            old_val = row.get("old_value", "").strip()
            new_val = row.get("new_value", "").strip()

            entry = {
                "audit_id": row.get("audit_id", "").strip(),
                "user_id": user_id,
                "event_time": row.get("event_time", "").strip(),
                "field_name": field_name,
                "old_value": old_val,
                "new_value": new_val,
            }
            audit_by_user.setdefault(user_id, []).append(entry)

            # Index historical email values so we can resolve older emails
            if field_name == "email":
                if old_val:
                    email_to_users.setdefault(normalize_email(old_val), set()).add(user_id)
                if new_val:
                    email_to_users.setdefault(normalize_email(new_val), set()).add(user_id)

    return audit_by_user, email_to_users

# What: Resolves a given email address to a unique user_id using current and historical tables.
# Why: Users may submit deletion requests with either their current email or an older email recorded only in the audit log.
def resolve_user_id(email, current_email_index, audit_email_index):
    norm_email = normalize_email(email)
    matched_ids = set()

    # 1. Search current identities
    if norm_email in current_email_index:
        for uid in current_email_index[norm_email]:
            matched_ids.add(uid)

    # 2. Search historical audit log
    if norm_email in audit_email_index:
        for uid in audit_email_index[norm_email]:
            matched_ids.add(uid)

    # Handle resolution outcomes defensively
    if len(matched_ids) == 0:
        return {
            "status": "NOT_FOUND",
            "user_id": None,
            "error": f"Email '{email}' was not found in current identities or historical audit logs."
        }
    elif len(matched_ids) > 1:
        return {
            "status": "AMBIGUOUS",
            "user_id": None,
            "candidate_ids": sorted(list(matched_ids)),
            "error": f"Email '{email}' is associated with multiple distinct users: {sorted(list(matched_ids))}."
        }
    else:
        return {
            "status": "RESOLVED",
            "user_id": next(iter(matched_ids)),
            "error": None
        }

# What: Collects all current and historical identifiers (name, emails, phones, email hashes) for a resolved user.
# Why: A complete deletion audit requires checking every identifier that ever belonged to the user across all system logs and databases.
def get_user_identity_bundle(user_id, users_by_id, audit_by_user):
    user_record = users_by_id.get(user_id, {})
    user_name = user_record.get("name", "")

    # Sets to aggregate all variations
    emails = set()
    phones = set()
    email_hashes = set()

    # Add current identifiers
    current_email = user_record.get("email", "")
    current_phone = user_record.get("phone", "")
    current_hash = user_record.get("email_hash", "")

    if current_email:
        emails.add(normalize_email(current_email))
    if current_phone:
        phones.add(current_phone)
    if current_hash:
        email_hashes.add(current_hash)

    # Add historical identifiers from audit log
    historical_events = audit_by_user.get(user_id, [])
    for event in historical_events:
        field = event["field_name"]
        old_v = event["old_value"]
        new_v = event["new_value"]

        for val in (old_v, new_v):
            if not val:
                continue
            if field == "email":
                emails.add(normalize_email(val))
            elif field == "phone":
                phones.add(val)
            elif field == "email_hash":
                email_hashes.add(val)

    return {
        "user_id": user_id,
        "name": user_name,
        "current": {
            "email": current_email,
            "phone": current_phone,
            "email_hash": current_hash,
        },
        "all_emails": sorted(list(emails)),
        "all_phones": sorted(list(phones)),
        "all_email_hashes": sorted(list(email_hashes)),
        "audit_event_count": len(historical_events),
        "audit_events": historical_events,
    }

# What: Coordinates full identity resolution for any incoming email query.
# Why: Provides a single, clean API function that takes an email and returns the full identity profile.
def resolve_identity(email, identities_csv="dataset/user_identities.csv", audit_csv="dataset/user_audit_log.csv"):
    users_by_id, current_email_index = load_user_identities(identities_csv)
    audit_by_user, audit_email_index = load_user_audit_log(audit_csv)

    resolution = resolve_user_id(email, current_email_index, audit_email_index)
    if resolution["status"] != "RESOLVED":
        return resolution

    bundle = get_user_identity_bundle(resolution["user_id"], users_by_id, audit_by_user)
    return {
        "status": "RESOLVED",
        "query_email": email,
        "bundle": bundle,
        "error": None
    }

# What: Demonstrates identity resolution on selected sample cases, including historical and edge cases.
# Why: Verifies that our identity engine correctly handles direct matches, historical changes, and missing users.
def run_stage_2_demo():
    print("=" * 80)
    print("STAGE 2: IDENTITY RESOLUTION & IDENTIFIER BUNDLE DEMO")
    print("=" * 80)

    # 5 test cases from sample dataset plus 1 edge case demo
    test_cases = [
        {"case_id": "case_01", "email": "amina.elmasri@gmail.com", "note": "Standard direct match (current email)"},
        {"case_id": "case_02", "email": "mateo.rios@outlook.com", "note": "Standard direct match (current email)"},
        {"case_id": "case_10", "email": "nadia.ionescu@yahoo.com", "note": "Historical email! Not in user_identities.csv"},
        {"case_id": "case_12", "email": "minjun.kim@gmail.com", "note": "Current email match with older email in audit log"},
        {"case_id": "case_15", "email": "lucia-torres@gmail.com", "note": "Current email match with older phone in audit log"},
    ]

    for item in test_cases:
        print(f"\n--- Case: {item['case_id']} | Query Email: {item['email']} ---")
        print(f"Scenario: {item['note']}")
        result = resolve_identity(item["email"])

        if result["status"] == "RESOLVED":
            b = result["bundle"]
            print(f"Status      : {result['status']}")
            print(f"User ID     : {b['user_id']}")
            print(f"Name        : {b['name']}")
            print(f"All Emails  : {b['all_emails']}")
            print(f"All Phones  : {b['all_phones']}")
            print(f"All Hashes  : {b['all_email_hashes']}")
            print(f"Audit Events: {b['audit_event_count']} historical change events found")
            for ev in b["audit_events"]:
                print(f"   -> [{ev['event_time']}] {ev['field_name']}: '{ev['old_value']}' => '{ev['new_value']}'")
        else:
            print(f"Status: {result['status']} | Error: {result['error']}")

    # Edge case demo: Email not found
    print("\n--- Edge Case Test: Unknown Email ---")
    unknown_email = "nonexistent.user.999@example.com"
    unknown_result = resolve_identity(unknown_email)
    print(f"Query: {unknown_email}")
    print(f"Result Status: {unknown_result['status']}")
    print(f"Result Message: {unknown_result['error']}")
    print("=" * 80)

if __name__ == "__main__":
    run_stage_2_demo()
